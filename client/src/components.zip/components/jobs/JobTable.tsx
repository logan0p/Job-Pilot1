import JobRow from "./JobRow";

type Job = {
  id: string;
  company: string;
  position: string;
  location: string;
  salary: string;
  status: string;
};

type Props = {
  jobs: Job[];
  onEdit: (job: Job) => void;
};

const JobTable = ({
  jobs,
  onEdit,
}: Props) => {
  return (
    <div className="overflow-hidden rounded-3xl border border-slate-700 bg-slate-900/70 backdrop-blur-xl">

      <div className="overflow-x-auto">

        <table className="min-w-full">

          <thead className="bg-slate-800">

            <tr>

              <th className="px-6 py-5 text-left">
                Company
              </th>

              <th className="px-6 py-5 text-left">
                Position
              </th>

              <th className="px-6 py-5 text-left">
                Location
              </th>

              <th className="px-6 py-5 text-left">
                Salary
              </th>

              <th className="px-6 py-5 text-left">
                Status
              </th>

              <th className="px-6 py-5 text-center">
                Actions
              </th>

            </tr>

          </thead>

          <tbody>

            {jobs.length === 0 ? (

              <tr>

                <td
                  colSpan={6}
                  className="py-20 text-center text-slate-400"
                >
                  No Jobs Found
                </td>

              </tr>

            ) : (

              jobs.map((job) => (

                <JobRow
                  key={job.id}
                  job={job}
                  onEdit={onEdit}
                />

              ))

            )}

          </tbody>

        </table>

      </div>

    </div>
  );
};

export default JobTable;