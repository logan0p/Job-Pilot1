import { motion } from "framer-motion";
import StatusBadge from "./StatusBadge";
import ActionButtons from "./ActionButtons";

type Job = {
  id: string;
  company: string;
  position: string;
  location: string;
  salary: string;
  status: string;
};

type Props = {
  job: Job;
  onEdit: (job: Job) => void;
};

const JobRow = ({
  job,
  onEdit,
}: Props) => {
  return (
    <motion.tr
      initial={{
        opacity: 0,
        y: 10,
      }}
      animate={{
        opacity: 1,
        y: 0,
      }}
      whileHover={{
        scale: 1.01,
      }}
      transition={{
        duration: 0.2,
      }}
      className="
      border-b
      border-slate-800
      hover:bg-slate-800/40
      transition
      "
    >
      <td className="px-6 py-5">

        <div className="flex flex-col">

          <span className="font-semibold text-white">
            {job.company}
          </span>

        </div>

      </td>

      <td className="px-6 py-5">

        {job.position}

      </td>

      <td className="px-6 py-5">

        {job.location || "-"}

      </td>

      <td className="px-6 py-5">

        {job.salary || "-"}

      </td>

      <td className="px-6 py-5">

        <StatusBadge
          status={job.status}
        />

      </td>

      <td className="px-6 py-5">

        <ActionButtons
          onEdit={() => onEdit(job)}
          onDelete={() => {
            console.log("Delete", job.id);
          }}
        />

      </td>

    </motion.tr>
  );
};

export default JobRow;