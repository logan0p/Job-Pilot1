import {
  Pencil,
  Trash2,
} from "lucide-react";

type Props = {
  onEdit: () => void;
  onDelete: () => void;
};

const ActionButtons = ({
  onEdit,
  onDelete,
}: Props) => {
  return (
    <div className="flex items-center justify-center gap-3">

      <button
        onClick={onEdit}
        className="
        w-10
        h-10
        rounded-xl
        bg-cyan-500/15
        text-cyan-400
        hover:bg-cyan-500
        hover:text-white
        transition-all
        duration-300
        "
      >
        <Pencil
          size={18}
          className="mx-auto"
        />
      </button>

      <button
        onClick={onDelete}
        className="
        w-10
        h-10
        rounded-xl
        bg-red-500/15
        text-red-400
        hover:bg-red-500
        hover:text-white
        transition-all
        duration-300
        "
      >
        <Trash2
          size={18}
          className="mx-auto"
        />
      </button>

    </div>
  );
};

export default ActionButtons;