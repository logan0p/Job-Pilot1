import { useState } from "react";
import type { ReactNode } from "react";

import Sidebar from "./Sidebar";
import Navbar from "./Navbar";

type Props = {
  children: ReactNode;
};

const Layout = ({ children }: Props) => {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Fixed Sidebar */}
      <Sidebar collapsed={collapsed} />

      {/* Main Content */}
      <div
        className={`
          transition-all
          duration-300
          ${collapsed ? "ml-20" : "ml-72"}
        `}
      >
        {/* Fixed Navbar */}
        <Navbar
          collapsed={collapsed}
          setCollapsed={setCollapsed}
        />

        {/* Page Content */}
        <main
          className="
            pt-8
            px-8
            pb-8
            min-h-[calc(100vh-96px)]
          "
        >
          <div className="mx-auto w-full max-w-7xl">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default Layout;