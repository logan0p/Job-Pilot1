import {
  FaHome,
  FaBriefcase,
  FaChartPie,
  FaCog,
  FaSignOutAlt,
} from "react-icons/fa";

import { Rocket } from "lucide-react";
import { NavLink } from "react-router-dom";

type Props = {
  collapsed: boolean;
};

const Sidebar = ({ collapsed }: Props) => {
  const menu = [
    {
      title: "Dashboard",
      icon: <FaHome size={20} />,
      path: "/dashboard",
    },
    {
      title: "Jobs",
      icon: <FaBriefcase size={20} />,
      path: "/jobs",
    },
    {
      title: "Analytics",
      icon: <FaChartPie size={20} />,
      path: "/analytics",
    },
    {
      title: "Settings",
      icon: <FaCog size={20} />,
      path: "/settings",
    },
  ];

  return (
    <aside
      className={`
        fixed
        top-0
        left-0
        h-screen
        bg-slate-900
        border-r
        border-slate-800
        transition-all
        duration-300
        z-50
        flex
        flex-col
        ${collapsed ? "w-20" : "w-72"}
      `}
    >
      {/* Logo */}
      <div className="border-b border-slate-800 px-6 py-6">

        <div className="flex items-center gap-3">

          <Rocket
            size={34}
            className="text-cyan-400 shrink-0"
          />

          {!collapsed && (
            <div>

              <h1 className="text-4xl font-black text-cyan-400">
                JobPilot
              </h1>

              <p className="text-slate-400">
                Track every opportunity.
              </p>

            </div>
          )}

        </div>

      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-5">

        {menu.map((item) => (

          <NavLink
            key={item.title}
            to={item.path}
            className={({ isActive }) =>
              `
              mb-2
              flex
              items-center
              rounded-xl
              px-4
              py-3
              transition-all
              ${
                isActive
                  ? "bg-cyan-600 text-white"
                  : "text-slate-300 hover:bg-slate-800"
              }
              ${collapsed ? "justify-center" : "gap-4"}
              `
            }
          >
            {item.icon}

            {!collapsed && (
              <span className="font-medium">
                {item.title}
              </span>
            )}

          </NavLink>

        ))}

      </nav>

      {/* Bottom User */}
      <div className="border-t border-slate-800 p-4">

        {!collapsed && (

          <div className="mb-4 flex items-center gap-3">

            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 text-xl font-bold">

              B

            </div>

            <div>

              <p className="font-semibold">
                Commander
              </p>

              <p className="text-sm text-slate-400">
                Software Engineer
              </p>

            </div>

          </div>

        )}

        <button
          className={`
            flex
            w-full
            items-center
            rounded-xl
            border
            border-red-500/20
            bg-red-500/10
            py-3
            text-red-400
            hover:bg-red-500/20
            transition
            ${collapsed ? "justify-center" : "justify-center gap-3"}
          `}
        >
          <FaSignOutAlt />

          {!collapsed && "Logout"}

        </button>

      </div>

    </aside>
  );
};

export default Sidebar;