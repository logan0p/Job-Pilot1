import StatCard from "./StatCard";

type Props = {
  data: {
    totalJobs: number;
    Applied: number;
    Interview: number;
    Offer: number;
    Rejected: number;
  };
};

const DashboardCards = ({ data }: Props) => {
  return (
    <div
      className="
        grid
        gap-6
        grid-cols-1
        sm:grid-cols-2
        lg:grid-cols-3
        2xl:grid-cols-5
      "
    >
      <StatCard
        title="Total"
        value={data.totalJobs}
        color="text-white"
      />

      <StatCard
        title="Applied"
        value={data.Applied}
        color="text-blue-400"
      />

      <StatCard
        title="Interview"
        value={data.Interview}
        color="text-yellow-400"
      />

      <StatCard
        title="Offer"
        value={data.Offer}
        color="text-green-400"
      />

      <StatCard
        title="Rejected"
        value={data.Rejected}
        color="text-red-400"
      />
    </div>
  );
};

export default DashboardCards;